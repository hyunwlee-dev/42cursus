/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hyunwlee <hyunwlee@student.42.kr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/26 01:30:15 by hyunwlee          #+#    #+#             */
/*   Updated: 2020/12/30 16:42:32 by hyunwlee         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	char	*src_tmp;

	if (!dst && !src)
		return (0);
	src_tmp = (char *)src;
	if (dstsize > 0)
	{
		while (*src_tmp && --dstsize)
			*(dst++) = *(src_tmp++);
		*dst = '\0';
	}
	return (ft_strlen(src));
}
