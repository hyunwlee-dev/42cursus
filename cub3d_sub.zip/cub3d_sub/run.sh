#!/bin/bash

cd ./libft
make fclean
make re
cp libft.a ../
make fclean
make clean
cd ..


